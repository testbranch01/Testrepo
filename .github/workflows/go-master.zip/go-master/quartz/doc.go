// Package quartz is a simple, zero-dependency scheduling library for Go.
// Inspired by the Quartz Java scheduler.
//
// See README.md for more info.
package quartz
